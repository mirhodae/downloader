<?php
/**
 * Admin class for FBT Templates for Bricks Builder
 *
 * @package FBT_Templates_For_Bricks_Builder
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin class for handling settings page and license management
 */
class FBT_Templates_For_Bricks_Builder_Admin {

    /**
     * Constructor
     */
    public function __construct() {
        // Constructor initialization
    }

    /**
     * Initialize the admin
     *
     * @return void
     */
    public function init() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        
        // No AJAX handlers needed
        
        // Enqueue admin scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Add admin menu
     *
     * @return void
     */
    public function add_admin_menu() {
        add_submenu_page(
            'options-general.php',
            __('FBT Templates for Bricks Builder', 'fbt-templates-for-bricks-builder'),
            __('FBT Templates for Bricks Builder', 'fbt-templates-for-bricks-builder'),
            'manage_options',
            'fbt-templates-for-bricks-builder',
            array($this, 'render_settings_page')
        );
    }

    

    /**
     * Render a template card
     */
    private function render_template_card($template, $type = 'free') {
        // Ensure we have a valid preview URL
        $preview_url = isset($template['preview']) ? $template['preview'] : FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/placeholder.jpg?v=' . time();
        ?>
        <div class="template-card <?php echo esc_attr($type); ?>">
            <div class="template-card-header">
                <h4><?php echo esc_html($template['title']); ?></h4>
            </div>
            <div class="template-card-image">
                <img src="<?php echo esc_url($preview_url); ?>" alt="<?php echo esc_attr($template['title']); ?>">
                <span class="template-badge <?php echo esc_attr($type); ?>"><?php echo esc_html(ucfirst($type)); ?></span>
            </div>
        </div>
        <?php
    }

    /**
     * Render a premium template card with purchase link
     */
    private function render_premium_template_card($template) {
        // Default URL if not provided
        $url = isset($template['url']) ? $template['url'] : 'https://example.com';
        // Ensure we have a valid image URL
        $image_url = isset($template['image']) ? $template['image'] : FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/placeholder.jpg?v=' . time();
        ?>
        <div class="template-card premium">
            <div class="template-card-header">
                <h4><?php echo esc_html($template['title']); ?></h4>
            </div>
            <div class="template-card-image">
                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer">
                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($template['title']); ?>">
                    <span class="template-badge premium">Premium</span>
                </a>
                <div class="template-card-actions">
                    <a href="<?php echo esc_url($url); ?>" class="button button-primary" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Get Template', 'fbt-templates-for-bricks-builder'); ?></a>
                </div>
            </div>
        </div>
        <?php
    }

    
    /**
     * Set cache prevention headers
     * This helps prevent browsers from caching our admin pages and assets
     */
    private function set_cache_prevention_headers() {
        // Only set headers if we haven't sent them yet
        if (!headers_sent()) {
            header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
            header("Cache-Control: post-check=0, pre-check=0", false);
            header("Pragma: no-cache");
            header("Expires: 0");
        }
    }

    /**
     * Enqueue admin scripts
     *
     * @param string $hook Current admin page
     * @return void
     */
    public function enqueue_admin_scripts($hook) {
        // Always load our admin styles on all admin pages to ensure they're available
        // Use time() for aggressive cache-busting
        $cache_buster = time();
        
        // Set cache prevention headers for admin pages
        $this->set_cache_prevention_headers();
        
        wp_enqueue_style(
            'fbt-templates-for-bricks-builder-admin',
            FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/css/admin.css',
            array(),
            $cache_buster
        );
        
    }

    /**
     * Display mixed templates in the admin with alternating rows
     * First row: free, Second row: premium, Third row: free, Fourth row: premium
     */
    private function display_mixed_templates() {
        // Clear any template transients to ensure fresh data
        delete_transient('fbt_templates_for_bricks_builder_free_templates');
        delete_transient('fbt_templates_for_bricks_builder_premium_templates');
        
        // Define your free templates here for manual customization
        $free_templates = [
            // Row 1 (Free)
            [
                'title' => 'Hero Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/fbt-hero-1.jpg?v=' . time()
            ],
            [
                'title' => 'Hero Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/fbt-hero-3.jpg?v=' . time()
            ],
            [
                'title' => 'Hero Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/fbt-hero-7.jpg?v=' . time()
            ],
            // Row 3 (Free)
            [
                'title' => 'Testimonial Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Testimonials-3-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Testimonial Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Testimonials-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Call to Action Block',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/fbt-hero-7.jpg?v=' . time()
            ],
            // Row 5 (Free)
            [
                'title' => 'Features Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Features-3-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Features Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Testimonials-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Feature Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Features-6-Template.jpg?v=' . time()
            ],
            // Row 7 (Free)
            [
                'title' => 'Features Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Features-7-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Features Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-Features-8-Template.jpg?v=' . time()
            ],
            [
                'title' => 'Features Section Template',
                'preview' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/FBT-features-10-Template.jpg?v=' . time()
            ],
        ];
        
        // Define your premium templates here for manual customization
        $premium_templates = [
            // Row 2 (Premium)
            [
                'title' => 'Ai Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/ai.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Cleaning Company Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/cleaning.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Travel Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/travel.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            // Row 4 (Premium)
            [
                'title' => 'Construction Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/construction.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Gardening Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/Gardening.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Plumber Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/plumber.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            // Row 6 (Premium)
            [
                'title' => 'Architect Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/architect.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Consulting Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/consulting.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Tech Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/tech.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            // Row 8 (Premium)
            [
                'title' => 'Creative Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/creative.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Startup Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/startup.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
            [
                'title' => 'Blogger Full Website Template',
                'image' => FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL . 'assets/images/blogger.webp?v=' . time(),
                'url' => 'https://freebrickstemplates.com/best-bricks-builder-templates/'
            ],
        ];
        
        // Display templates in alternating rows (3 templates per row)
        $free_chunks = array_chunk($free_templates, 3);
        $premium_chunks = array_chunk($premium_templates, 3);
        $total_rows = max(count($free_chunks), count($premium_chunks));
        
        for ($i = 0; $i < $total_rows; $i++) {
            // Display free templates row (odd rows: 1, 3, 5, 7)
            if (isset($free_chunks[$i])) {
                echo '<div class="template-row free-row">';
                echo '<div class="row-label"><span class="badge free-badge">Free</span></div>';
                echo '<div class="template-grid">';
                foreach ($free_chunks[$i] as $template) {
                    $this->render_template_card($template, 'free');
                }
                echo '</div></div>';
            }
            
            // Display premium templates row (even rows: 2, 4, 6, 8)
            if (isset($premium_chunks[$i])) {
                echo '<div class="template-row premium-row">';
                echo '<div class="row-label"><span class="badge premium-badge">Premium</span></div>';
                echo '<div class="template-grid">';
                foreach ($premium_chunks[$i] as $template) {
                    $this->render_premium_template_card($template);
                }
                echo '</div></div>';
            }
        }
    }
    
    /**
     * Render settings page with template showcase
     *
     * @return void
     */
    public function render_settings_page() {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="templates-info">
                <h3><?php esc_html_e('Bricks Templates Collection', 'fbt-templates-for-bricks-builder'); ?></h3>
                <h4><?php esc_html_e('Browse our collection of templates for Bricks Builder. Free templates are included with the plugin and premium templates are available for purchase. The free templates will be avialable in your Bricks Editor area in Templates section', 'fbt-templates-for-bricks-builder'); ?></h4>
            </div>
            
            <div class="mixed-templates-container">
                <?php $this->display_mixed_templates(); ?>
            </div>
        </div>
        <?php
    }

    // License-related AJAX handlers removed
}
