=== FBT Templates for Bricks Builder ===
Contributors: Khangood
Tags: Bricks builder templates, premium templates, free bricks templates.
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


# FBT Templates For Bricks Builder

A WordPress plugin that adds free and premium Bricks Builder templates to the Bricks editor.

## Description

FBT Templates For Bricks Builder enhances your Bricks Builder experience by providing access to both free directly within the Bricks editor.

## Features

– **Free Templates**: Access bundled templates directly in the Bricks editor
– **Premium Templates**: buy it from our website https://freebrickstemplates.com
– **Template Badges**: Premium templates are clearly labeled in the editor

## Requirements

– WordPress 5.8 or higher
– PHP 7.4 or higher
– Bricks Builder 1.9 or higher

## Installation

1. Upload the `fbt-templates-for-bricks-builder` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


## Add Free Templates

To add free templates To your :

1. Install and activate the plugin
2. Edit a page or post with Bricks Builder
3. Click on the Templates Icon the Free templates will be load.
4. Select Insert to add the template to your page or post.
5. You can also customize the template as needed

The plugin will automatically detect and load all JSON files in the templates directory.

## Activating Premium Templates

To access premium templates:

1. Purchase The Tem plates from Freebrickstmeplates.com
2. Download the Zip file you get after purchase
3. Upload the templates into your Bricks Editor
4. Make sure before importing you have activated 'import images' option in the template import panel.


## Frequently Asked Questions

### Where can I find the free templates?

Free templates are included in the plugin's `templates` directory. You can also add your own templates to this directory.You can load the templates from Bricks builder editor by click on the templates icon.


### How often are templates updated?

We update the templates from time to time. 


## License

This plugin is licensed under the GPL v2 or later.

== Changelog ==
1.0 - July 21, 2025
Version 1.0 released


## Credits

Developed by FBT Team




