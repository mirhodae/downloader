<?php
/**
 * Plugin Name: FBT Templates for Bricks Builder
 * Plugin URI: https://freebrickstemplates.com/fbt-bricks-templates-plugin/
 * Description: Adds free and premium Bricks Builder templates to the Bricks editor.
 * Version: 1.0.0
 * Author: FBT Team
 * Author URI: https://freebrickstemplates.com
 * Text Domain: fbt-templates-for-bricks-builder
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Set cache prevention headers for better template image loading
if (!headers_sent() && isset($_GET['page']) && $_GET['page'] === 'fbt-templates-for-bricks-builder') {
    // Only verify nonce if we're performing an action (not on initial page load)
    if (is_admin() && isset($_GET['action']) && !empty($_GET['action'])) {
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'fbt_templates_for_bricks_builder_nonce')) {
            wp_die(esc_html__('Invalid nonce specified', 'fbt-templates-for-bricks-builder'), esc_html__('Error', 'fbt-templates-for-bricks-builder'), array('response' => 403));
        }
    }
    
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    header("Expires: 0");
}

// Define plugin constants
define('FBT_TEMPLATES_FOR_BRICKS_BUILDER_VERSION', '1.0.0');
define('FBT_TEMPLATES_FOR_BRICKS_BUILDER_FILE', __FILE__);
define('FBT_TEMPLATES_FOR_BRICKS_BUILDER_PATH', plugin_dir_path(__FILE__));
define('FBT_TEMPLATES_FOR_BRICKS_BUILDER_URL', plugin_dir_url(__FILE__));
define('FBT_TEMPLATES_FOR_BRICKS_BUILDER_BASENAME', plugin_basename(__FILE__));

// Register activation hook
register_activation_hook(__FILE__, 'fbt_templates_for_bricks_builder_activation');

/**
 * Function that runs on plugin activation
 */
function fbt_templates_for_bricks_builder_activation() {
    // Add option to redirect after activation
    add_option('fbt_templates_for_bricks_builder_do_activation_redirect', true);
}

/**
 * Handle redirect after activation
 */
function fbt_templates_for_bricks_builder_redirect() {
    // Check if we should redirect
    if (get_option('fbt_templates_for_bricks_builder_do_activation_redirect', false)) {
        // Delete the redirect option
        delete_option('fbt_templates_for_bricks_builder_do_activation_redirect');
        // Redirect to settings page
        wp_safe_redirect(admin_url('options-general.php?page=fbt-templates-for-bricks-builder'));
        exit;
    }
}

// Include required files
require_once FBT_TEMPLATES_FOR_BRICKS_BUILDER_PATH . 'includes/class-fbt-templates-for-bricks-builder.php';
require_once FBT_TEMPLATES_FOR_BRICKS_BUILDER_PATH . 'admin/class-fbt-templates-for-bricks-builder-admin.php';

/**
 * Initialize the plugin
 *
 * @return void
 */
function fbt_templates_for_bricks_builder_init() {
    // Check if Bricks Builder is active - either as a plugin or theme
    $is_bricks_active = class_exists('\Bricks\Elements') || 
                        (function_exists('wp_get_theme') && 
                         (wp_get_theme()->get('TextDomain') === 'bricks' || 
                          (wp_get_theme()->parent() && wp_get_theme()->parent()->get('TextDomain') === 'bricks')));
    
    if (!$is_bricks_active) {
        add_action('admin_notices', 'fbt_templates_for_bricks_builder_admin_notice');
        return;
    }
    
    // Add redirect action
    add_action('admin_init', 'fbt_templates_for_bricks_builder_redirect');
    
    // Initialize the plugin
    $fbt_templates_for_bricks_builder = new FBT_Templates_For_Bricks_Builder();
    $fbt_templates_for_bricks_builder->init();
    
    // Initialize the admin
    if (is_admin()) {
        $fbt_templates_for_bricks_builder_admin = new FBT_Templates_For_Bricks_Builder_Admin();
        $fbt_templates_for_bricks_builder_admin->init();
    }
}
add_action('plugins_loaded', 'fbt_templates_for_bricks_builder_init');

/**
 * Admin notice if Bricks Builder is not active
 *
 * @return void
 */
function fbt_templates_for_bricks_builder_admin_notice() {
    $class = 'notice notice-error';
    $message = __('FBT Templates for Bricks Builder requires Bricks Builder to be installed and activated as either a theme or a plugin.', 'fbt-templates-for-bricks-builder');
    printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
}


/**
 * Deactivation hook
 */
register_deactivation_hook(__FILE__, 'fbt_templates_for_bricks_builder_deactivate');
function fbt_templates_for_bricks_builder_deactivate() {
    // Clear cached templates
    delete_transient('fbt_templates_for_bricks_builder_premium_templates');
}

/**
 * Uninstall hook
 */
register_uninstall_hook(__FILE__, 'fbt_templates_for_bricks_builder_uninstall');
function fbt_templates_for_bricks_builder_uninstall() {
    // Clear cached templates
    delete_transient('fbt_templates_for_bricks_builder_premium_templates');
    delete_transient('fbt_templates_for_bricks_builder_free_templates');
}
