/**
 * FBT Bricks Templates - Admin JavaScript
 * Reserved for future admin functionality
 */
